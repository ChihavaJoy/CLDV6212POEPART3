﻿namespace ABCRetailers.Services
{
    public class StorageInitializer
    {
        public static async Task InitializeStorageAsync(IAzureStorageService storageService)
        {
            if (storageService == null)
                throw new ArgumentNullException(nameof(storageService));

            await storageService.CreateTableAsync("CustomersTable");
            await storageService.CreateTableAsync("ProductsTable");
            await storageService.CreateTableAsync("OrdersTable");
        }
    }
}
