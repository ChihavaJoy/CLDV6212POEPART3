﻿using ABCRetailers.Models;
using ABCRetailers.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ABCRetailers.Controllers
{
    public class ProductController : Controller
    {
        private readonly IAzureStorageService _storageService;
        private readonly ILogger<ProductController> _logger;
        private const string TableName = "Products";

        public ProductController(IAzureStorageService storageService, ILogger<ProductController> logger)
        {
            _storageService = storageService;
            _logger = logger;
        }

        // GET: Product
        public async Task<IActionResult> Index()
        {
            var products = await _storageService.GetAllEntitiesAsync<Product>(TableName);
            return View(products.OrderBy(p => p.ProductName));
        }

        // GET: Product/Create
        public IActionResult Create()
        {
            ViewBag.JordanTypes = GetProductTypes();
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, IFormFile? imageFile)
        {
            if (product.Price <= 0)
                ModelState.AddModelError("Price", "Price must be greater than 0.");

            if (!ModelState.IsValid)
            {
                ViewBag.JordanTypes = GetProductTypes(product);
                return View(product);
            }

            try
            {
                // Use enum value as PartitionKey
                product.PartitionKey = product.ProductType.ToString();
                product.RowKey = Guid.NewGuid().ToString();

                // Upload image if provided
                if (imageFile != null && imageFile.Length > 0)
                {
                    var imageUrl = await _storageService.UploadBlobAsync("product-images", imageFile);
                    product.ImageUrl = imageUrl;
                }

                await _storageService.AddEntityAsync(TableName, product);
                TempData["Success"] = $"Product '{product.ProductName}' created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product");
                ModelState.AddModelError("", $"Error creating product: {ex.Message}");
                ViewBag.JordanTypes = GetProductTypes(product);
                return View(product);
            }
        }

        // GET: Product/Edit/5
        public async Task<IActionResult> Edit(string id, string partitionKey)
        {
            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(partitionKey))
                return NotFound();

            var product = await _storageService.GetEntityAsync<Product>(TableName, partitionKey, id);
            if (product == null)
                return NotFound();

            ViewBag.JordanTypes = GetProductTypes(product);
            return View(product);
        }

        // POST: Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Product product, IFormFile? imageFile)
        {
            if (product.Price <= 0)
                ModelState.AddModelError("Price", "Price must be greater than 0.");

            if (!ModelState.IsValid)
            {
                ViewBag.JordanTypes = GetProductTypes(product);
                return View(product);
            }

            try
            {
                var original = await _storageService.GetEntityAsync<Product>(TableName, product.PartitionKey, product.RowKey);
                if (original == null) return NotFound();

                original.ProductName = product.ProductName;
                original.Description = product.Description;
                original.Price = product.Price;
                original.StockAvailable = product.StockAvailable;
                original.ProductType = product.ProductType;

                if (imageFile != null && imageFile.Length > 0)
                {
                    var imageUrl = await _storageService.UploadBlobAsync("product-images", imageFile);
                    original.ImageUrl = imageUrl;
                }

                await _storageService.UpdateEntityAsync(TableName, original);
                TempData["Success"] = "Product updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating product");
                ModelState.AddModelError("", $"Error updating product: {ex.Message}");
                ViewBag.JordanTypes = GetProductTypes(product);
                return View(product);
            }
        }

        // POST: Product/Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string id, string partitionKey)
        {
            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(partitionKey))
                return NotFound();

            try
            {
                await _storageService.DeleteEntityAsync(TableName, partitionKey, id);
                TempData["Success"] = "Product deleted successfully!";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error deleting product: {ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }

        private List<SelectListItem> GetProductTypes(Product product = null)
        {
            var list = new List<SelectListItem>();
            foreach (JordanType type in Enum.GetValues(typeof(JordanType)))
            {
                list.Add(new SelectListItem
                {
                    Value = type.ToString(),
                    Text = type.ToString(),
                    Selected = product != null && product.ProductType == type
                });
            }
            return list;
        }
    }
}
