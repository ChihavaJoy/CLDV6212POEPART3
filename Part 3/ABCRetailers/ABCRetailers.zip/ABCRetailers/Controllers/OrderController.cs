﻿using ABCRetailers.Models.ViewModels;
using ABCRetailers.Models;
using ABCRetailers.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ABCRetailers.Controllers
{
    public class OrderController : Controller
    {
        private readonly IAzureStorageService _storageService;
        private const string TableName = "Orders"; 

        public OrderController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        // Display all orders
        public async Task<IActionResult> Index()
        {
            var orders = await _storageService.GetAllEntitiesAsync<Order>(TableName);
            return View(orders);
        }

        // Display order creation form with dropdowns for customers and products
        public async Task<IActionResult> Create()
        {
            var customers = await _storageService.GetAllEntitiesAsync<Customer>("Customers");
            var products = await _storageService.GetAllEntitiesAsync<Product>("Products");

            var viewModel = new OrderCreateViewModel
            {
                Customers = customers,
                Products = products
            };

            return View(viewModel);
        }

        // Handle create order form submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderCreateViewModel model)
        {
            if (!ModelState.IsValid)
            {
                await PopulateDropdowns(model);
                return View(model);
            }

            try
            {
                // Validate customer and product
                var customer = await _storageService.GetEntityAsync<Customer>("Customers", model.CustomerId, model.CustomerId);
                var product = await _storageService.GetEntityAsync<Product>("Products", model.ProductId, model.ProductId);

                if (customer == null || product == null)
                {
                    ModelState.AddModelError("", "Invalid customer or product selected.");
                    await PopulateDropdowns(model);
                    return View(model);
                }

                // Check stock availability
                if (product.StockAvailable < model.Quantity)
                {
                    ModelState.AddModelError("Quantity", $"Insufficient stock. Available: {product.StockAvailable}");
                    await PopulateDropdowns(model);
                    return View(model);
                }

                // Create new order entity
                var order = new Order
                {
                    CustomerId = model.CustomerId,
                    Username = customer.Username,
                    ProductId = model.ProductId,
                    ProductName = product.ProductName,
                    OrderDate = model.OrderDate,
                    Quantity = model.Quantity,
                    UnitPrice = product.Price,
                    Status = "Submitted"
                };

                await _storageService.AddEntityAsync(TableName, order);

                // Update product stock
                product.StockAvailable -= model.Quantity;
                await _storageService.UpdateEntityAsync("Products", product);

                // Send message to order queue
                var orderMessage = new
                {
                    OrderId = order.OrderId,
                    CustomerId = order.CustomerId,
                    CustomerName = customer.Name + " " + customer.Surname,
                    ProductName = product.ProductName,
                    Quantity = order.Quantity,
                    TotalPrice = order.UnitPrice * order.Quantity,
                    OrderDate = order.OrderDate,
                    Status = order.Status
                };

                await _storageService.SendMessageAsync("order-notifications", JsonSerializer.Serialize(orderMessage));

                TempData["Success"] = "Order created successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error creating order: {ex.Message}");
                await PopulateDropdowns(model);
                return View(model);
            }
        }

        // Display order details
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var order = await _storageService.GetEntityAsync<Order>(TableName, id, id);
            if (order == null) return NotFound();

            return View(order);
        }

        // Display edit form for an existing order
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var order = await _storageService.GetEntityAsync<Order>(TableName, id, id);
            if (order == null) return NotFound();

            return View(order);
        }

        // Handle edit order form submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Order order)
        {
            if (!ModelState.IsValid) return View(order);

            try
            {
                await _storageService.UpdateEntityAsync(TableName, order);
                TempData["Success"] = "Order updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error updating order: {ex.Message}");
                return View(order);
            }
        }

        // Delete an order
        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                await _storageService.DeleteEntityAsync(TableName, id, id);
                TempData["Success"] = "Order deleted successfully!";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error deleting order: {ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }

        // Helper method to repopulate dropdowns in case of errors
        private async Task PopulateDropdowns(OrderCreateViewModel model)
        {
            model.Customers = await _storageService.GetAllEntitiesAsync<Customer>("Customers");
            model.Products = await _storageService.GetAllEntitiesAsync<Product>("Products");
        }
    }
}
